"""Setup script for duke-agents package."""
from setuptools import setup

# Read version from __version__.py
exec(open('src/duke_agents/__version__.py').read())

setup()