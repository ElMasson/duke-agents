"""Version information for duke-agents."""

__version__ = "1.0.0"
__author__ = "Stephane MASSON"
__email__ = "smasson@duke-ai.io"
